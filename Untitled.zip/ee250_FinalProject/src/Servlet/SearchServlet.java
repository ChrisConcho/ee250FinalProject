package Servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;




/**
 * Servlet implementation class SearchServlet
 */
@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static String API_KEY = "0646dd6512c2607f5dfb135a4c066f938ef46a56aadcc468793eccceaed85558";

	/**
	 * Default constructor.
	 */
	public SearchServlet() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String next=  "/Home.jsp";
		String state = request.getParameter("states");
		int[] timestamps = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
		double values[] = { 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0 };
		
		String api = callUnpluggAPI(timestamps,values);
		System.out.println(api);
		String url="https://covidtracking.com/api/v1/states/";
		url += state + "/daily.json";
		
		HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
		connection.setRequestMethod("GET");
		BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"));
		StringBuilder response1 = new StringBuilder();
		String responseLine = null;
		while ((responseLine = br.readLine()) != null) {
			response1.append(responseLine.trim());
		}
		System.out.println(response1.toString());
		JsonArray jarr = new JsonParser().parse(response1.toString()).getAsJsonArray();
		JsonArray retJarr = new JsonArray();
		String json = "[";
		for(JsonElement x: jarr) {
			String date = x.getAsJsonObject().get("date").toString();
			date = date.substring(0,4) + "-"+ date.substring(4,6)+"-"+date.substring(6,8);
			System.out.println(date);
			LocalDate localDate = LocalDate.parse(date);
			Instant instant = localDate.atStartOfDay(ZoneId.systemDefault()).toInstant();
			long timeInMillis = instant.toEpochMilli();
			String element = "{ \"date\" :"+timeInMillis+ ", \"units\": "+ x.getAsJsonObject().get("positive") + "}";
			if ( jarr.get(jarr.size()-1) != x){
				element+= ",";
			}
			json += element;
		}
		json += "]";
		System.out.println(json);
		request.setAttribute("json", json);
		request.setAttribute("currstate",state);
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher(next);
		dispatch.forward(request,response);
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		
		

	}

	public static String callUnpluggAPI(int[] timestamps, double[] values) {
		String url = "https://api.unplu.gg/forecast";
		String jsonObj = null;

		String body = "{\"data\": [";

		for (int i = 0; i < timestamps.length; i++) {
			body += "{\"timestamp\":" + timestamps[i] + ",\"value\":" + values[i] + "}";
			if (i != timestamps.length - 1) {
				body += ",";
			}
		}
		
		body += "],\"forecast_to\":20, \"callback\": \"Ee250FinalProject-env.eba-ymxkht25.us-east-2.elasticbeanstalk.com/data.json\"}\n";
		
//		List<Object> enabledEvents = new ArrayList<>();
//		enabledEvents.add("charge.failed");
//		enabledEvents.add("charge.succeeded");
//		Map<String, Object> params = new HashMap<>();
//		params.put(
//		  "url",
//		  "https://example.com/my/webhook/endpoint"
//		);
//		params.put("enabled_events", enabledEvents);
//
//		WebhookEndpoint webhookEndpoint =
//		  WebhookEndpoint.create(params);

		System.out.println(body);
		try {
			HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();

			connection.setRequestMethod("POST");

			connection.setRequestProperty("x-access-token", API_KEY);
			connection.setRequestProperty("Content-Type", "application/json");
			connection.setDoOutput(true);
			OutputStream os = connection.getOutputStream();
			byte[] input = body.getBytes("utf-8");
			os.write(input, 0, input.length);

			BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"));
			StringBuilder response = new StringBuilder();
			String responseLine = null;
			while ((responseLine = br.readLine()) != null) {
				response.append(responseLine.trim());
			}
			System.out.println(response.toString());
			jsonObj = response.toString();

		} catch (ProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (jsonObj != null) {
			return jsonObj;
		}
		return "hey";
	}

}
